#include<iostream>
using namespace std;
int main()
{
	
	int * array ;//A pointer is created named 'array'
	int l;//will be the size 
	
	
	cout<<"Enter the size of the array: ";
	cin>>l;//taking the size input from the user
	const int s=l;//setting the size as a constant variable so it does not change while the program runs 
	array=new int[s];//dynamically allocating the array with size 's'
	
	cout<<"Enter the elements of the array :"<<endl;
		for(int i=0;i<s;i++)
		{
			cout<<"Element "<<i+1<<":";
			cin>>*(array+i);//taking input elements from the user
		}
		cout<<"Array:::  {";
	for(int j=0;j<s;j++)
		{
			cout<<*(array+j);//displaing the variables of the array
			if(j<s-1)
			cout<<",";
		}
	cout<<"}";
	
}
