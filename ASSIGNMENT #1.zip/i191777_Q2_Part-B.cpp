#include<iostream>
using namespace std;
int main()
{


	int m, n;//m is for the rows and n for columns


	cout << "Enter the no. of rows of the Matrix 1: ";
	cin >> m;//enter the number of rows from user
	cout << "Enter the no. of col of the Matrix 1: ";
	cin >> n;//take the no of columns from user
	const int r1 = m;//storing the no of rows in a constant variable
	const int c1 = n;//storing the no of rows in a constant variable
	int* array = new int[r1 * c1];//dynamically allocating the array
	int i, j;//declaration for loops
	cout << "Enter the elements of the Matrix 1 :" << endl;
	for (i = 0; i < r1; i++)//the first matrix rows
	{
		for (j = 0; j < c1; j++)//first matrix columns
		{
			cout << "Input in row " << i + 1 << " col " << j + 1 << ":::";
			cin >> *(array + i * c1 + j);//taking the elements from the user storing in a dynamically allocated 2d array 
		}
		cout << endl;
	}

	cout << "MATRIX 1:::" << endl;

	for (i = 0; i < r1; i++)//displaying the matrix
	{
		cout << "| ";
		for (j = 0; j < c1; j++)
		{

			cout << *(array + i * c1 + j);
			if (j < c1 - 1)
				cout << ",";
		}cout << " |";
		if (i < r1 - 1)
			cout << endl;
	}





	cout << endl;
	cout << "Enter the no. of rows of the Matrix 2: ";
	cin >> m;//rows for second matrix
	cout << "Enter the no. of col of the Matrix 2: ";
	cin >> n;//columns for second matrix
	const int r2 = m;//constant rows
	const int c2 = n;//constant columns
	int* array2 = new int[r2 * c2];//dynamically allocating the second array (matrix)

	cout << "Enter the elements of the Matrix 2 :" << endl;
	for (i = 0; i < r2; i++)//taking inputs in the second matrix(row
	{
		for (j = 0; j < c2; j++)//columns
		{
			cout << "Input in row " << i + 1 << " col " << j + 1 << ":::";
			cin >> *(array2 + i * c2 + j);//input
		}
		cout << endl;
	}

	cout << "MATRIX 2:::" << endl;//displaying the second matrix 

	for (i = 0; i < r2; i++)
	{
		cout << "| ";
		for (j = 0; j < c2; j++)
		{

			cout << *(array2 + i * c2 + j);//elements input


			if (j < c2 - 1)
				cout << ",";
		}cout << " |";
		if (i < r2 - 1)
			cout << endl;
	}


	//can they be multiplied??
	int sum;
	int* mult = new int[r1 * c2];
	if (c1 == r2)//check the size of cols of first and rows of second then multiplication is possible
	{
		for (i = 0; i < r1; ++i)
			for (j = 0; j < c2; ++j) {
				*(mult + i * c2 + j) = 0;//as it has size of row of 1 and col of second 
				for (int k = 0; k < c1; ++k)
				{
					*(mult + i * c2 + j) += (*(array + i * c1 + k)) * (*(array2 + k * c2 + j));//storing the values in another(resultant) matrix
				}
			}


		cout << endl << "MULTIPLIED MATRIX: " << endl;//output matrix
		for (i = 0; i < r1; ++i)
		{
			cout << "| ";
			for (j = 0; j < c2; ++j)
			{
				cout << *(mult + i * c2 + j);
				if (j < c2 - 1)
					cout << ",";
			}
			cout << " |";
			if (i < r1 - 1)
				cout << endl;
		}
	}
	else
		cout << "THEY CAN NOT BE MULTIPLIED AS COLUMNS OF FIRST MATRIX IS NOT EQUAL TO ROWS OF SECOND MATRIX";




}
