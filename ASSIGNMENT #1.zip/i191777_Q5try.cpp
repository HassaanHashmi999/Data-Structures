#include<iostream>
#include<cstdlib>
#include<time.h>
#include<unistd.h>
using namespace std;

char** GOL;

void display();
int l=0;
int main(){
	GOL=new char*[30];
	for(int i=0; i<30; i++)
		GOL[i]=new char[30];
		
	srand(time(NULL));
	
	for(int i=0; i<30; i++){
		for(int j=0; j<30; j++){
			if(rand()%2)
				GOL[i][j]='*';
			else
				GOL[i][j]=' ';
		}
	}
	display();
	cout<<"This is Life at the beginning\n\n\n";
	sleep(1);
	
	
	while(1){
		if(l>0)
		cout<<"GENERATION::"<<l<<endl;
	for(int i=1; i<29; i++){
		for(int j=1; j<29; j++){
			
			
			
				int alive=0;
				if(GOL[i][j]=='*'){
				
					if(GOL[i][j+1]=='*')
					alive++;
					if(GOL[i][j-1]=='*')
					alive++;
					if(GOL[i+1][j]=='*')
					alive++;
					if(GOL[i-1][j]=='*')
					alive++;
					if(GOL[i+1][j+1]=='*')
					alive++;
					if(GOL[i+1][j-1]=='*')
					alive++;
					if(GOL[i-1][j-1]=='*')
					alive++;
					if(GOL[i-1][j+1]=='*')
					alive++;
					if(alive<2)
					GOL[i][j]=' ';
				else if(alive==3 || alive==2)
					GOL[i][j]='*';
				else
					GOL[i][j]=' ';
					
				}
				else
				{
					if(GOL[i][j+1]=='*')
					alive++;
					if(GOL[i][j-1]=='*')
					alive++;
					if(GOL[i+1][j]=='*')
					alive++;
					if(GOL[i-1][j]=='*')
					alive++;
					if(GOL[i+1][j+1]=='*')
					alive++;
					if(GOL[i+1][j-1]=='*')
					alive++;
					if(GOL[i-1][j-1]=='*')
					alive++;
					if(GOL[i-1][j+1]=='*')
					alive++;
					
						if(alive==3)
					GOL[i][j]='*';
				
					
				}
		}
	}
	sleep(1.5);
	
	display();
	
	l++;
	}
				
				
}	

void display(){
	cout<<endl<<endl<<endl<<endl<<endl;
	for(int i=0; i<30; i++){
		for(int j=0; j<30; j++){
			cout<<GOL[i][j]<<' ';
		}
		cout<<endl;
	}
	cout<<endl<<endl;
}
