#include <iostream>
using namespace std;

struct arr {
    int size;
    int array[50];
};

int main() {
    int i, j,  sumsize = 0, r = 0;
    int k;
    //no of arrays
    cout << "Enter the number of arrays:";
    cin >> k;

    arr* A = new arr[k];//creating an array of structure arr so many arrays can be generated. 
    for (i = 0; i < k; i++)
    {
        cout << "The array no. " << i + 1 << ":";
        cout << "Enter the size:";
        cin >> A[i].size;//taking size of the array

        sumsize = sumsize + A[i].size;//taking a sum so can be used for merged array
        for (j = 0; j < A[i].size; j++)
        {
            cout << "ENTER ELEMENT NO." << j + 1 << ":";
            cin >> A[i].array[j];//inputing element from user
            
            if (j > 0) {
                while (A[i].array[j] < A[i].array[j - 1])//error condition
                {
                    cout << "ERROR!!\nEnter the Elements in ascending order:";
                    cout << "\nENTER ELEMENT NO." << j + 1 << " Again:";
                    cin >> A[i].array[j];
                }
            }
          

        }
    }

    int* arri = new int[sumsize];//a new merged array
    for (i = 0; i < k; i++)
    {
        for (j = 0; j < A[i].size; j++)
        {
            arri[r] = A[i].array[j];//storing the values of arrays into the merged array

            ++r;
        }
    }
    cout << "ARRAY::\n{ ";
    for (i = 0; i < sumsize; i++)
    {
        cout << arri[i];//merged array elements printing
        if (i < sumsize - 1)
            cout << " , ";
    }
    cout << " }";
	for(i=0;i<sumsize;++i)
		for(j=i+1;j<sumsize;)
			{
				if(arri[i]==arri[j])//checking for duplicate element
				{
					for(k=j;k<sumsize-1;++k)
					arri[k]=arri[k+1];//storing is the previous index of the array
					--sumsize;//decreasing the size of the array
				}
				else
					++j;
			}
	cout << "\n\nWithout Duplicate Numbers \n{ ";
    for (i = 0; i < sumsize; i++)
    {
        cout << arri[i];//display
        if (i < sumsize - 1)
            cout << " , ";
    }
    cout << " }";
    
    int a;
        for (i = 0; i < sumsize; ++i) 
         for (j = i + 1; j < sumsize; ++j) 
             if (arri[i] < arri[j]) //sorting in decending order 
                {
                    a = arri[i];//a here is a temp to store the smaller element
                    arri[i] = arri[j];//bigger element stored in the smaller index
                    arri[j] = a;//moving the smaller element into the bigger index
                }//bubble sort
            
        
    
    cout << "\n\nIn Decending Order \n{ ";
    for (i = 0; i < sumsize; i++)
    {
        cout << arri[i];//display
        if (i < sumsize - 1)
            cout << " , ";
    }
    cout << " }";
    

    
    return 0;
}
