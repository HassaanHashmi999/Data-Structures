#include<iostream>
#include<cstdlib>
#include<time.h>
#include<unistd.h>
using namespace std;

char** GOL;

void display();
int l=0;

//doesnot run on visual studio as it does not library #include<unistd.h>
int main(){
	GOL=new char*[31];
	for(int i=1; i<31; i++)
		GOL[i]=new char[31];
		
	srand(time(NULL));
	
	for(int i=1; i<31; i++){
		for(int j=1; j<31; j++){
			if(rand()%2)//random numbers 0 and 1 to assign alive or dead
				GOL[i][j]='*';
			else
				GOL[i][j]=' ';
		}
	}
	display();
	cout<<"This is Life at the beginning\n\n\n";
	sleep(1);
	
	
	while(1){
		if(l>0)
		cout<<"GENERATION::"<<l<<endl;
	for(int i=1; i<30; i++){
		for(int j=1; j<30; j++){
			
			
			
				int alive=0;
				if(GOL[i][j]=='*')//check for alive element
				{
				
					if(GOL[i][j+1]=='*')//neighbour
					alive++;
					if(GOL[i][j-1]=='*')//neighbour
					alive++;
					if(GOL[i+1][j]=='*')//neighbour
					alive++;
					if(GOL[i-1][j]=='*')//neighbour
					alive++;
					if(GOL[i+1][j+1]=='*')//neighbour
					alive++;
					if(GOL[i+1][j-1]=='*')//.
					alive++;
					if(GOL[i-1][j-1]=='*')//..
					alive++;
					if(GOL[i-1][j+1]=='*')//...
					alive++;
					if(alive<2)//if less than 2 neighbours alive then it dies
					GOL[i][j]=' ';
				else if(alive==3 || alive==2)//if 2 or 3 neighbours alive then it stays alive
					GOL[i][j]='*';
				else
					GOL[i][j]=' ';
					
				}
				else//checks for dead 
				{
					if(GOL[i][j+1]=='*')
					alive++;
					if(GOL[i][j-1]=='*')
					alive++;
					if(GOL[i+1][j]=='*')
					alive++;
					if(GOL[i-1][j]=='*')
					alive++;
					if(GOL[i+1][j+1]=='*')
					alive++;
					if(GOL[i+1][j-1]=='*')
					alive++;
					if(GOL[i-1][j-1]=='*')
					alive++;
					if(GOL[i-1][j+1]=='*')
					alive++;
					
						if(alive==3)//it gets life if 3 neighbours are alive
					GOL[i][j]='*';
				
					
				}
		}
	}
	sleep(1.5);
	
	display();
	
	l++;
	}
				
				
}	

void display(){
	cout<<endl<<endl<<endl<<endl<<endl;
	for(int i=1; i<31; i++){
		for(int j=1; j<31; j++){
			cout<<GOL[i][j]<<' ';//display the grid
		}
		cout<<endl;
	}
	cout<<endl<<endl;
}
