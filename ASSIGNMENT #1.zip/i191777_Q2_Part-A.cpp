#include<iostream>
using namespace std;
int main()
{
	
	 
	int m,n,num;//m is for the rows and n for columns
	
	
	cout<<"Enter the no. of rows of the array: ";
	cin>>m;//input rows from user
	cout<<"Enter the no. of col of the array: ";
	cin>>n;//input columns from the user
	const int r = m;//making the size of rows constant
	const int c = n;//makin the size of columns constant
	int* array = new int[r * c];//dynamically allocating the array with constant size of rows & columns
	int i, j;//for using further loops
	cout << "Enter the elements of the array :" << endl;
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < c; j++)
		{
			cout << "Input in row " << i + 1 << " col " << j + 1 << ":::";
			cin >> *(array+i*c+j);//taking input elements from the user(with pointer notation)
		}
		cout << endl;
	}
	
		cout<<"Array:::"<<endl; //displaying the 2D array 
		
		for( i=0;i<r;i++)
		{
		cout<<"| ";
			for( j=0;j<c;j++)
		{
			
			cout<<*(array+i*c+j);//printing the elements of the array
			if(j<c-1)
			cout<<",";
		}cout<<" |";
			if(i<r-1)
		cout<<endl;//moving to the next row
		}
	cout<<"\n ROW Array:::"<<endl;  //printing the elemments giving prefrence to rows
		cout<<"| ";
		for( i=0;i<r;i++)//rows
		{
		
			for( j=0;j<c;j++)//columns
		{
			
			cout<<*(array+i*c+j);
			if(j<c-1 || i<r-1)
			cout<<",";
			//no end line
		}
		
		}
		cout<<" |";
	cout<<"\n COLUMN Array:::"<<endl; //printing the elements giving prefrence to columns 
		cout<<"| ";
		for( i=0;i<c;i++)//colums first
		{
		
			for( j=0;j<r;j++)//then rows
		{
			
			cout<<*(array+j*r+i);//columns are itrated first
			if(j<r-1 || i<c-1)
			cout<<",";
		}
		
		}	
	cout<<" |";

	
}
