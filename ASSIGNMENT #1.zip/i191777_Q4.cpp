
#include <iostream>
#include <string>
using namespace std;
int main()
{int i,tc;
bool check=1;
    string csrid[7]={"CSR_01", "CSR_02", "CSR_03", "CSR_04", "CSR_05"," CSR_06", "CSR_07"};
    string csrname[7];
  float hours[7];
   unsigned int issues[7];
   float pay[7];
   float wages[7];
    for (i = 0; i < 7; i++)
        {
        	//Display each csrID and ask the user to enter names, hours and complaintsResolved.
        	cout<<"For EMPLOYEE::"<<csrid[i]<<endl;
        	
        	cout<<"Enter the Name(First Name):";
        	cin>>csrname[i];
        	
			cout<<"Hours worked:";
			cin>>hours[i];
			
			if(check)
        	{
        		cout<<"Enter the Total No. of Complaients Resolved:";
        		cin>>tc;
        		check=0;
			}
			 cout<<"Complaints resolved by the EMPLOYEE :";
        	cin>>issues[i];
        	
        	pay[i]=25+25*(issues[i]/tc);
        	wages[i]=hours[i]*pay[i];
		}
	for ( i = 0; i < 7; i++)
		cout<<"ID::"<<csrid[i]<<"\tNAME :"<<csrname[i]<<"\tWAGES :"<<wages[i]<<"\tPay:"<<pay[i]<<endl;
	//Program should also display options to display the top N CSRs on the basis of different criteria,
	//including: number of complaintsResolved, number of hours worked.
	//most hours worked by
	
	int choice,c=1;
	
	int maxh,maxcr,h,cr;
	do{
	cout<<"CHECK \n 1)Number of complaintsResolved,   2)Number of hours worked,    3)END::";
	cin>>choice;//users choice in loop he/she has an option to end the program
	switch(choice)
	{
	case 1:
	maxh=hours[0];
	for (i = 1; i < 7; i++)
        if (hours[i] > maxh)
            {
			maxh = hours[i];
			h=i;
			}
	cout<<"\n\nFor Maximum Hours the Top Employee with ID::"<<csrid[h]<<"\t and NAME :"<<csrname[h]<<endl<<"HOURS WORKED::"<<hours[h]<<endl;	
	break;
	case 2:
	maxcr=issues[0];
	for (i = 1; i < 7; i++)
        if (issues[i] > maxh)
           {
           	maxcr = issues[i];
           	cr=i;
			} 
			
	cout<<"For Complaints Resolved the Top Employee with ID::"<<csrid[h]<<"\t and NAME :"<<csrname[h]<<endl<<"Complaints Resolved::"<<issues[h]<<endl;
	break;
	
	
	case 3:
		c=0;
		break;
}
}while(c==1);
	
}
