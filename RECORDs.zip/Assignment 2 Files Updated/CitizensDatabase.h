#ifndef CITIZENSDB_H
#define CITIZENSDB_H
#include <string>

template <class T>
struct Data {
	//Node structure for data pipeline, implement data members as per requirement
};
template <class T>
class DataPipeline {
	/*	A linkedlist based queue to implement databases
		Implement additional functions as per requirement
	*/
	Data<T>* head;
public:
	
	DataPipeline () {

	}

	T front() {
		return T();
	}
	T back() {
		return T();
	}

	T enqueue(T) {
	}

	T dequeue() {
		return T();
	}

	bool is_empty() {
		return false;
	}
};

struct CBID_NODE {
	//Implement additional data members and functions as per requirement
	CBID_NODE *next, *previous;
};

template <class T>
class CBIDList {
	//Implement data members and functions as per requirement

};

struct CCID_NODE {
	//Implement additional data members and functions as per requirement
	CCID_NODE *next, *previous;
};
template <class T>
class CCIDList {
	//Implement data members and functions as per requirement

};

template <class T>
class Database {
    
	CBIDList<T> CBID; //CBID Database
	CCIDList<T> CCID; //CCID Database
	DataPipeline<T> dataPipeline;
    
public:

	Database(const std::T& filename,const std::T& filename1) {
		/*
			Initialize the data from the given file and populate database
		*/
		
	}
    /*Return a string in following format "Name FName Gender Address Nationality Crimes(if any) Charges punishment fine number network activation_date deactivation_date status"
     Refer to test cases for further clerification*/
	T& CBID_Search_by_CNIC(int cnic) {
		
		return NULL;
	}
	T& CCID_Search_by_CNIC(int cnic) {

        return NULL;
    }
	
	bool updateCBIDName(T Name, int cnic) {
		/*update and return true when cnic found else return false*/
		return false;
	}

	bool updateCBIDFName(T Father_Name, int cnic) {
		/*update and return true when cnic found else return false*/
		return false;
	}

	bool updateCBIDAddress(T Address, int cnic) {
		/*update and return true when cnic found else return false*/
		return false;
	}

	bool updateCBIDNationality(T Nationality, int cnic) {
		/*update and return true when cnic found else return false*/
		return false;
	}
    bool addCrime(T cnic, T charges, T punishment, T fine){
        /*update and return true when crime found else return false*/
        return false;
    }

	bool updateCrime(T cnic, T charges, T punishment, T fine) {
		/*update and return true when crime found else return false*/
		return false;
	}

	bool deleteCrime(T cnic, T charges, T punishment, T fine) {
		/*update and return true when crime found else return false*/
		return false;
	}

	~Database() {
		/* deallocate and cleanup */
	}
};

#endif
